package controlador;

import conexion.Conexion;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.HeadlessException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author DIEGO
 */
public class reporte {
     public static void main(String[] args){
        imprimir();
      
    }
     
  public static void imprimir(){
       Document documento =new Document();
        
try{
    String ruta= System.getProperty("user.home");
    PdfWriter.getInstance(documento, new FileOutputStream(ruta + "/Desktop/Reporte de Calificacion.pdf"));
    Paragraph parrafo=new Paragraph(); 
    parrafo.setAlignment(Paragraph.ALIGN_CENTER);
    parrafo.add("Repote \n\n");
    parrafo.setFont(FontFactory.getFont("Tahoma",18,Font.BOLD,BaseColor.DARK_GRAY));
    parrafo.add("Reporte de clientes \n\n");
    documento.open();
    documento.add(parrafo);
    PdfPTable tabla = new PdfPTable(6);
    
    tabla.addCell("IdCliente");
    tabla.addCell("Nombre");
    tabla.addCell("Apellido");
    tabla.addCell("Cedula");
    tabla.addCell("Telefono");
    tabla.addCell("Cedula");
    tabla.addCell("Dirección");

    try{
        //Conexion mysql = new Conexion();
       Connection cn=Conexion.conectar();
       PreparedStatement pst = cn.prepareStatement("select idCliente,nombre,apellido,cedula,telefono,direccion from tb_cliente");
       ResultSet rs = pst.executeQuery();
       if(rs.next()){
           do{
               tabla.addCell(rs.getString(1));
               tabla.addCell(rs.getString(2));
               tabla.addCell(rs.getString(3));
               tabla.addCell(rs.getString(4));
               tabla.addCell(rs.getString(5));
               tabla.addCell(rs.getString(6));
               tabla.addCell(rs.getString(7));
               
               
           }while (rs.next());
           documento.add(tabla);
       }
    }catch(DocumentException | SQLException e){
    }
    documento.close();
    JOptionPane.showMessageDialog(null, "Reporte Fue creado en el Escritorio");
 }catch(DocumentException | HeadlessException | FileNotFoundException e){
                 System.out.println("Error 1 en: " + e);

 }
  }}