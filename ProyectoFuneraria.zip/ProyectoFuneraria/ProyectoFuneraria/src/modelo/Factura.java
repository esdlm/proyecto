/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author rgedu
 */
public class Factura {
    private int numeroFactura;

public Factura(){
this.numeroFactura=0;

//public Factura(int numeroFactura){
  //this.numeroFactura=numeroFactura;
}

    public int getNumeroFactura() {
        return numeroFactura;
    }

    public void setNumeroFactura(int numeroFactura) {
        this.numeroFactura = numeroFactura;
    }

}
