package modelo;


public class CabeceraVenta1 {
    
    //Atributos
    private int idCabeceraventa1;
    private double valorPagar1;
    private String fechaVenta1;
    private int estado1;
    
    //constructor
    public CabeceraVenta1(){
        this.idCabeceraventa1 = 0;
        this.valorPagar1 = 0.0;
        this.fechaVenta1 = "";
        this.estado1 = 0;
    }
    
     //constructor sobrecargado

    public CabeceraVenta1(int idCabeceraventa1, double valorPagar1, String fechaVenta1, int estado1) {
        this.idCabeceraventa1 = idCabeceraventa1;
        this.valorPagar1 = valorPagar1;
        this.fechaVenta1 = fechaVenta1;
        this.estado1 = estado1;
    }
    
    //get and set 

    public int getIdCabeceraventa1() {
        return idCabeceraventa1;
    }

    public void setIdCabeceraventa1(int idCabeceraventa1) {
        this.idCabeceraventa1 = idCabeceraventa1;
    }


    public double getValorPagar1() {
        return valorPagar1;
    }

    public void setValorPagar1(double valorPagar1) {
        this.valorPagar1 = valorPagar1;
    }

    public String getFechaVenta1() {
        return fechaVenta1;
    }

    public void setFechaVenta1(String fechaVenta1) {
        this.fechaVenta1 = fechaVenta1;
    }

    public int getEstado1() {
        return estado1;
    }

    public void setEstado1(int estado1) {
        this.estado1 = estado1;
    }
    
    //toString 

    @Override
    public String toString() {
        return "CabeceraVenta{" + "idCabeceraventa=" + idCabeceraventa1 + ", valorPagar=" + valorPagar1 + ", fechaVenta=" + fechaVenta1 + ", estado=" + estado1 + '}';
    }
    
    
    
}
